# v98.63 — Release cleanup

- Removed accumulated historical audit, changelog, QA and release-verification documents from the project root; retained only current release documentation.
- Removed duplicate, outdated Android workflow copies; `.github/workflows/main.yml` is the single maintained workflow.
- Removed obsolete design mockups and refreshed the retained screen inventory to match the current navigation order.
- Removed the promotional header tagline and simplified the document title.
- Reviewed history-clear wording and retained “Clear Unlocked History” because protected entries are intentionally preserved.
- Kept calculator, scientific mode, tools, converters, history, favorites, settings, themes and localization behavior intact.
- Updated release identity and service-worker cache namespace to v98.63.
